import os
import shlex
import subprocess
import shutil

def try_mkdir(dirname):
    """Create a directory if it doesn't already exist."""
    if not os.path.exists(dirname):
        try:
            os.makedirs(dirname)
        except Exception as e:
            print(f"Error creating directory {dirname}: {e}")

def call_xtb(filename, settings):
    """
    Function to run XTB calculations with given settings and organize output.
    It retains only selected files in the current folder.

    Parameters:
        filename (str): The input XYZ file to be processed by XTB.
        settings (dict): A dictionary of settings, e.g., number of threads, output reduction, etc.
    """
    # Set up environment variables for XTB
    os.environ["OMP_NUM_THREADS"] = str(settings["OMP_NUM_THREADS"])
    os.environ["MKL_NUM_THREADS"] = str(settings["MKL_NUM_THREADS"])

    # Run the first XTB command
    command = f"xtb --chrg 0 --uhf 3 --gbsa toluene --lmo --vfukui --esp {filename}"
    print(f"Running: {command}")
    args = shlex.split(command)
    with open("xtb.log", "a") as mystdout:
        process = subprocess.Popen(args, stdout=mystdout, stderr=subprocess.PIPE)
        out, err = process.communicate()

        if process.returncode != 0:
            print(f"Error in XTB calculation: {err.decode('utf-8')}")
        else:
            print(f"XTB calculation finished successfully: {err.decode('utf-8')}")

    # Run the second XTB command for IPEA calculations
    command = f"xtb --gbsa toluene --vomega --vipea {filename}"
    print(f"Running: {command}")
    args = shlex.split(command)
    with open("xtb_ipea.log", "a") as mystdout:
        process = subprocess.Popen(args, stdout=mystdout, stderr=subprocess.PIPE)
        out, err = process.communicate()

        if process.returncode != 0:
            print(f"Error in XTB IPEA calculation: {err.decode('utf-8')}")
        else:
            print(f"XTB IPEA calculation finished successfully: {err.decode('utf-8')}")

    # Retain only required files
    required_files = [filename, "xtb.log", "xtb_ipea.log", "xtb_esp_profile.dat", "xtb_esp.dat"]
    current_folder = os.getcwd()  # Get the current folder path

    # Remove other files and directories in the current folder
    for item in os.listdir(current_folder):
        if item not in required_files and os.path.isdir(item):
            try:
                shutil.rmtree(item)
            except Exception as e:
                print(f"Error deleting directory {item}: {e}")
        elif item not in required_files and os.path.isfile(item):
            try:
                os.remove(item)
            except Exception as e:
                print(f"Error deleting file {item}: {e}")

    print(f"Selected files have been retained in the current folder: {current_folder}.")

if __name__ == "__main__":
    # Example settings for XTB calculations
    settings = {
        "OMP_NUM_THREADS": 24,          # Number of threads for OpenMP
        "MKL_NUM_THREADS": 24,          # Number of threads for MKL
        "reduce_output": True           # Reduce intermediate files
    }

    # Get the current folder name as the input file (e.g., if current folder is '1', the file is '1.xyz')
    current_folder = os.getcwd()
    folder_name = os.path.basename(current_folder)
    input_file = f"{folder_name}.xyz"  # Construct the input file name based on the folder name

    # Check if the input file exists
    if not os.path.exists(input_file):
        print(f"Error: Input file {input_file} does not exist.")
        exit(1)

    # Call XTB with the input file and settings
    call_xtb(input_file, settings)

import os
import csv
import re


def find_bond_atom_file(parent_dir):
    """
    Find the bondAtom_index.txt file in the parent directory.
    """
    for file in os.listdir(parent_dir):
        if file.endswith("bondAtom_index.txt"):
            return os.path.join(parent_dir, file)
    raise FileNotFoundError("No file ending with 'bondAtom_index.txt' found in the parent directory.")


def parse_bond_atom_indices(file_path):
    """
    Parse the bondAtom_index.txt file to extract R1-R5 indices.
    """
    indices = {}
    with open(file_path, "r") as file:
        lines = file.readlines()
        for line in lines:
            match = re.match(r"(R\d+)_index:\s*(\d+)", line.strip())
            if match:
                key = match.group(1)  # R1, R2, R3, R4, R5
                value = int(match.group(2))  # Corresponding index
                indices[key] = value
    return indices


def parse_txt_file_to_csv(txt_file, bond_atom_file, output_csv):
    """
    Parse the input TXT file and bondAtom_index.txt to extract Mulliken charges, Wiberg bond orders,
    HOMO/LUMO energies, Fukui indices, Dipole moment, Alpha polarizability, Global electrophilicity index,
    Nucleophilicity, and Electrostatic potential data, and save them to a CSV file.
    """
    folder_name = os.path.basename(os.getcwd())  # Use the folder name as the first column

    # Parse bondAtom_index.txt to get R1-R5 indices
    bond_atom_indices = parse_bond_atom_indices(bond_atom_file)

    # Mulliken charges, Wiberg bond orders, Fukui indices, and other properties to extract
    mulliken_charges = {}
    wiberg_bond_orders = {}
    fukui_indices = {}

    homo_energy = None
    lumo_energy = None
    homo_lumo_gap = None

    dipole_moment = {"X": None, "Y": None, "Z": None}
    alpha_polarizability = None
    global_electrophilicity = None
    nucleophilicity = None

    electrostatic_values = []  # To store the last column of Electrostatic potential points

    with open(txt_file, "r") as file:
        lines = file.readlines()

    # Flags to track sections
    in_mulliken_charges = False
    in_wiberg_bond_orders = False
    in_fukui_indices = False
    in_electrostatic_points = False

    for i, line in enumerate(lines):
        line = line.strip()

        # Check if we are in the Mulliken charges section
        if line.startswith("Mulliken charges:"):
            in_mulliken_charges = True
            in_wiberg_bond_orders = False
            in_fukui_indices = False
            in_electrostatic_points = False
            continue
        elif line.startswith("Wiberg bond orders:"):
            in_mulliken_charges = False
            in_wiberg_bond_orders = True
            in_fukui_indices = False
            in_electrostatic_points = False
            continue
        elif line.startswith("HOMO energy:"):
            try:
                homo_energy = float(lines[i + 1].strip())
            except (ValueError, IndexError):
                print(f"Error parsing HOMO energy from line: {line}")
            continue
        elif line.startswith("LUMO energy:"):
            try:
                lumo_energy = float(lines[i + 1].strip())
            except (ValueError, IndexError):
                print(f"Error parsing LUMO energy from line: {line}")
            continue
        elif line.startswith("HOMO-LUMO gap:"):
            try:
                homo_lumo_gap = float(lines[i + 1].strip())
            except (ValueError, IndexError):
                print(f"Error parsing HOMO-LUMO gap from line: {line}")
            continue
        elif line.startswith("Fukui indices:"):
            in_mulliken_charges = False
            in_wiberg_bond_orders = False
            in_fukui_indices = True
            in_electrostatic_points = False
            continue
        elif line.startswith("Electrostatic potential profile:"):
            in_fukui_indices = False
            in_electrostatic_points = False
            continue
        elif line.startswith("Electrostatic potential points:"):
            in_mulliken_charges = False
            in_wiberg_bond_orders = False
            in_fukui_indices = False
            in_electrostatic_points = True
            continue
        elif line.startswith("Dipole moment:"):
            try:
                dipole_values = lines[i + 1].strip().split()
                dipole_moment["X"] = float(dipole_values[0])
                dipole_moment["Y"] = float(dipole_values[1])
                dipole_moment["Z"] = float(dipole_values[2])
            except (ValueError, IndexError):
                print(f"Error parsing Dipole moment from line: {line}")
            continue
        elif line.startswith("Alpha polarizability:"):
            try:
                alpha_polarizability = float(lines[i + 1].strip())
            except (ValueError, IndexError):
                print(f"Error parsing Alpha polarizability from line: {line}")
            continue
        elif line.startswith("Global electrophilicity index:"):
            try:
                global_electrophilicity = float(lines[i + 1].strip())
            except (ValueError, IndexError):
                print(f"Error parsing Global electrophilicity index from line: {line}")
            continue
        elif line.startswith("Nucleophilicity:"):
            try:
                nucleophilicity = float(lines[i + 1].strip())
            except (ValueError, IndexError):
                print(f"Error parsing Nucleophilicity from line: {line}")
            continue

        # Parse Mulliken charges
        if in_mulliken_charges:
            parts = line.split()
            if len(parts) >= 1:  # Ensure there is at least one column
                try:
                    index = len(mulliken_charges) + 1  # Mulliken charge indices start from 1
                    charge = float(parts[0])  # Extract the first column as a float
                    mulliken_charges[index] = charge
                except ValueError:
                    continue

        # Parse Wiberg bond orders
        if in_wiberg_bond_orders:
            if line:  # Ensure the line is not empty
                try:
                    index = len(wiberg_bond_orders) + 1  # Bond order indices start from 1
                    bond_order = float(line.split()[0])  # Extract the bond order value
                    wiberg_bond_orders[index] = bond_order
                except ValueError:
                    continue

        # Parse Fukui indices
        if in_fukui_indices:
            parts = line.split()
            if len(parts) == 3:  # Each line should have three columns: f+, f-, f0
                try:
                    index = len(fukui_indices) + 1
                    fukui_indices[index] = {
                        "f+": float(parts[0]),
                        "f-": float(parts[1]),
                        "f0": float(parts[2]),
                    }
                except ValueError:
                    continue

        # Parse Electrostatic potential points
        if in_electrostatic_points:
            parts = line.split()
            if len(parts) == 4:  # Ensure the line has 4 columns
                try:
                    electrostatic_values.append(float(parts[3]))  # Take the last column
                except ValueError:
                    continue

    # Calculate the max and min of the electrostatic potential values
    electrostatic_max = max(electrostatic_values) if electrostatic_values else None
    electrostatic_min = min(electrostatic_values) if electrostatic_values else None

    # Prepare data for Mulliken charges (1, 2, 3, 4 and R1-R5)
    fixed_indices = [1, 6, 7]
    variable_indices = list(bond_atom_indices.keys())  # Use R1-R5 as column names
    mulliken_columns = [f"Mulliken_charges_{i}" for i in fixed_indices] + \
                       [f"Mulliken_charges_{key}" for key in variable_indices]
    mulliken_data = [mulliken_charges.get(i, None) for i in fixed_indices] + \
                    [mulliken_charges.get(bond_atom_indices[key], None) for key in variable_indices]

    # Prepare data for Wiberg bond orders (1, 2, 3, 4 and R1-R5)
    wiberg_columns = [f"Wiberg_bond_order_{i}" for i in fixed_indices] + \
                     [f"Wiberg_bond_order_{key}" for key in variable_indices]
    wiberg_data = [wiberg_bond_orders.get(i, None) for i in fixed_indices] + \
                  [wiberg_bond_orders.get(bond_atom_indices[key], None) for key in variable_indices]

    # Prepare data for Fukui indices
    fukui_columns = []
    fukui_data = []
    for i in fixed_indices:
        fukui_columns += [f"f+_{i}", f"f-_{i}", f"f0_{i}"]
        f_indices = fukui_indices.get(i, {"f+": None, "f-": None, "f0": None})
        fukui_data += [f_indices["f+"], f_indices["f-"], f_indices["f0"]]
    for key in variable_indices:
        fukui_columns += [f"f+_{key}", f"f-_{key}", f"f0_{key}"]
        f_indices = fukui_indices.get(bond_atom_indices[key], {"f+": None, "f-": None, "f0": None})
        fukui_data += [f_indices["f+"], f_indices["f-"], f_indices["f0"]]

    # Add additional properties
    additional_columns = [
        "HOMO_energy", "LUMO_energy", "HOMO_LUMO_gap",
        "Dipole_moment_X", "Dipole_moment_Y", "Dipole_moment_Z",
        "Alpha_polarizability", "Global_electrophilicity_index", "Nucleophilicity",
        "Electrostatic_max", "Electrostatic_min"
    ]
    additional_data = [
        homo_energy, lumo_energy, homo_lumo_gap,
        dipole_moment["X"], dipole_moment["Y"], dipole_moment["Z"],
        alpha_polarizability, global_electrophilicity, nucleophilicity,
        electrostatic_max, electrostatic_min
    ]

    # Write to the CSV file
    with open(output_csv, "w", newline="") as csvfile:
        csv_writer = csv.writer(csvfile)
        csv_writer.writerow(
            ["Folder_Name"] + mulliken_columns + wiberg_columns + fukui_columns + additional_columns
        )
        csv_writer.writerow([folder_name] + mulliken_data + wiberg_data + fukui_data + additional_data)

    print(f"Converted file saved to: {output_csv}")


if __name__ == "__main__":
    txt_file = "Electronic-results.txt"
    parent_dir = os.path.dirname(os.getcwd())
    output_csv = "Electronic-results.csv"

    try:
        bond_atom_file = find_bond_atom_file(parent_dir)
        parse_txt_file_to_csv(txt_file, bond_atom_file, output_csv)
    except Exception as e:
        print(f"Error: {e}")

import os
import shutil
from morfeus.conformer import ConformerEnsemble

def calculate_boltzmann_weights(folder):
    """
    Calculate Boltzmann weights for 

ormers in the given folder and save to a txt file.
    
    Parameters:
        folder (str): Path to the folder containing crest output files.
        
    Returns:
        None. Generates a txt file with Boltzmann weights.
    """
    try:
        # Load the conformer ensemble from the crest output folder
        ce = ConformerEnsemble.from_crest(folder)
        
        # Print the total number of conformers
        print(f"Conformer ensemble loaded with {len(ce)} conformers.")
        
        # Sort the conformers by energy
        ce.sort()
        
        # Get relative energies
        relative_energies = ce.get_relative_energies()
        
        # Get degeneracies
        degeneracies = ce.get_degeneracies()
        
        # Calculate Boltzmann weights
        boltzmann_weights = ce.boltzmann_weights()
        
        # Prepare output file path
        folder_name = os.path.basename(os.path.normpath(folder))  # Get the folder name
        output_file = os.path.join(folder, f"{folder_name}_boltzmann_weights.txt")
        
        # Write results to a txt file
        with open(output_file, "w") as f:
            f.write("Conformer Boltzmann weights:\n")
            for i, (energy, weight) in enumerate(zip(relative_energies, boltzmann_weights)):
                f.write(f"{folder_name}_conformer_{i + 1}: Energy = {energy:.4f} kcal/mol, Boltzmann weight = {weight:.4f}\n")
        
        print(f"Boltzmann weights saved to: {output_file}")
    
    except Exception as e:
        print(f"Error while calculating Boltzmann weights: {e}")

if __name__ == "__main__":
    # Specify the current directory as the crest output folder
    crest_folder = os.getcwd()  # Current directory
        
    # Calculate Boltzmann weights
    print(f"Calculating Boltzmann weights for crest output in: {crest_folder}")
    calculate_boltzmann_weights(crest_folder)

# -*- coding: utf-8 -*-

import os
import numpy as np
from Dscribe import get_G1, get_G2, get_G3, compute_G4, compute_G5  # Import symmetry function calculators
from ase import Atoms

# Function to read the XYZ file
def read_xyz(filename):
    with open(filename, 'r') as file:
        lines = file.readlines()

    num_atoms = int(lines[0].strip())  # First line is the number of atoms
    atom_symbols = []
    positions = []

    for line in lines[2:2 + num_atoms]:  # Skip the first two lines (number of atoms and comment)
        parts = line.split()
        atom_symbols.append(parts[0])
        positions.append([float(x) for x in parts[1:4]])

    return num_atoms, np.array(atom_symbols), np.array(positions)

# Function to read R2-R3 indices from the bondAtom_index.txt file in the parent directory
def read_bond_atom_indices():
    parent_dir = os.path.abspath(os.path.join(os.getcwd(), ".."))  # Move to the parent directory
    bond_atom_file = None

    # Search for the bondAtom_index.txt file
    for file in os.listdir(parent_dir):
        if file.endswith("bondAtom_index.txt"):
            bond_atom_file = os.path.join(parent_dir, file)
            break

    if bond_atom_file is None:
        raise FileNotFoundError("No file ending with 'bondAtom_index.txt' found in the parent directory.")

    # Read the R2-R3 indices from the file
    indices = {}
    with open(bond_atom_file, "r") as file:
        for line in file:
            if ":" in line:  # Ensure valid lines with ':' separator
                key, value = line.split(":")
                indices[key.strip()] = int(value.strip())

    # Ensure R2_index and R3_index are present
    required_keys = ["R1_index", "R2_index"]
    for key in required_keys:
        if key not in indices:
            raise KeyError(f"Missing {key} in {bond_atom_file}")

    return indices

# Function to calculate symmetry functions for a given XYZ file
def calculate_G_values(atom_symbols, positions, Rc, atom_index, g1_params, g2_params, g3_params, g4_params, g5_params):
    all_G_values = []

    # Calculate G1 symmetry functions
    G1_values = get_G1(positions, Rc, atom_index)
    all_G_values.append(G1_values)

    # Calculate G2 symmetry functions
    if g2_params is not None:
        G2_values = get_G2(positions, Rc, g2_params, atom_index)
        all_G_values.append(G2_values)

    # Calculate G3 symmetry functions
    if g3_params is not None:
        G3_values = get_G3(positions, Rc, g3_params, atom_index)
        all_G_values.append(G3_values)

    # Calculate G4 symmetry functions
    if g4_params is not None:
        G4_values = compute_G4(positions, Rc, g4_params, atom_index)
        all_G_values.append(G4_values)

    # Calculate G5 symmetry functions
    if g5_params is not None:
        G5_values = compute_G5(positions, Rc, g5_params, atom_index)
        all_G_values.append(G5_values)

    # Combine all G symmetry functions into a single array
    if all_G_values:
        G_values_combined = np.hstack(all_G_values)  # Flatten the list of arrays into one array
        print(f"Shape of G_values for atom index {atom_index + 1}: {G_values_combined.shape}")
        return G_values_combined

    return None

def main():
    # Get the current folder name
    current_folder = os.path.basename(os.getcwd())
    xyz_file = f"{current_folder}.xyz"

    # Check if the XYZ file exists
    if not os.path.exists(xyz_file):
        print(f"Error: File '{xyz_file}' not found in the current folder")
        return

    # Read R2-R3 indices from the bondAtom_index.txt file
    try:
        bond_atom_indices = read_bond_atom_indices()
        print(f"Successfully read bond atom indices: {bond_atom_indices}")
    except Exception as e:
        print(f"Error reading bond atom indices: {e}")
        return

    # Set the cutoff radius and symmetry function parameters
    Rc = 6.0  # Cutoff radius
    g1_params = []  # G1 parameters
    g2_params = [[1, 1], [1, 2], [1, 3]]  # G2 parameters
    g3_params = None  # G3 parameters
    g4_params = [[1, 1, 1], [1, 2, 1], [1, 1, -1], [1, 2, -1]]  # G4 parameters
    g5_params = None  # G5 parameters

    # Read the XYZ file
    try:
        num_atoms, atom_symbols, positions = read_xyz(xyz_file)
        print(f"Successfully loaded {xyz_file} with {num_atoms} atoms.")
    except Exception as e:
        print(f"Error reading XYZ file '{xyz_file}': {e}")
        return

    # Specify the atom indices to calculate (Atom 1, 4, 15, R2 and R3)
    atom_indices = [
        0,  # Atom 1 (0-based)
        6,  # Atom 4 (0-based)
        bond_atom_indices["R2_index"] - 1,  # R2 (0-based)
    ]  # Combine fixed indices and bond indices

    # Generate titles for Atom 1, Atom 4, Atom 15, Atom R2, and Atom R3
    bond_titles = [
        "Atom 1", "Atom 7", "Atom R2"
    ]

    all_results = []  # List to store results
    for idx, atom_index in enumerate(atom_indices):
        if atom_index < num_atoms:
            G_values = calculate_G_values(atom_symbols, positions, Rc, atom_index, g1_params, g2_params, g3_params, g4_params, g5_params)
            if G_values is not None:
                print(f"G values for {bond_titles[idx]}:")
                print(G_values)
                # Flatten G_values to ensure it's a 1D array before storing
                all_results.append((bond_titles[idx], G_values.flatten()))  # Save atom title and G values
        else:
            print(f"Warning: Atom index {atom_index + 1} is out of bounds for this molecule.")

    # Save results to a TXT file
    output_file = "ACSF_results.txt"
    with open(output_file, mode='w') as file:
        file.write(f"ACSF Results for file: {xyz_file}\n")
        file.write(f"Cutoff radius (Rc): {Rc}\n")
        file.write("=" * 50 + "\n")
        for title, G_values in all_results:
            file.write(f"{title}:\n")
            # Flatten G_values to ensure it's a 1D list, then format each value
            file.write(" ".join([f"{value:.6f}" for value in G_values]) + "\n")
            file.write("-" * 50 + "\n")

    print(f"\nResults have been saved to {output_file}")

if __name__ == "__main__":
    main()

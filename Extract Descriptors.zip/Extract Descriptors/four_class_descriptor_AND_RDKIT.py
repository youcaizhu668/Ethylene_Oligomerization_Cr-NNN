import os
import pandas as pd

def process_merge_all_csv(main_folder, input_csv, output_csv):
    # Load the merge_all.csv file
    input_path = os.path.join(main_folder, input_csv)
    data = pd.read_csv(input_path)

    # Initialize a dictionary to store Boltzmann weights from all txt files
    boltzmann_weights = {}

    # Parse all files ending with "boltzmann_weights.txt"
    for file_name in os.listdir(main_folder):
        if file_name.endswith("boltzmann_weights.txt"):  # Check for matching files
            file_path = os.path.join(main_folder, file_name)
            with open(file_path, "r") as file:
                for line in file:
                    # Only process lines containing "Boltzmann weight ="
                    if "Boltzmann weight =" in line:
                        parts = line.split(":")  # Split by ":"
                        folder_name = parts[0].strip()  # Extract folder name (e.g., L100002_conformer_1)
                        try:
                            weight_str = parts[-1].split("=")[-1].strip()  # Extract Boltzmann weight as string
                            if weight_str:  # Ensure weight_str is not empty
                                weight = float(weight_str)  # Convert to float
                                boltzmann_weights[folder_name] = weight
                            else:
                                print(f"Warning: Boltzmann weight is missing for {folder_name} in file {file_name}")
                        except ValueError:
                            print(f"Warning: Failed to parse Boltzmann weight for {folder_name} in file {file_name}")
                    else:
                        print(f"Skipping non-data line: {line.strip()}")

    # Initialize lists for descriptors and values
    descriptors = ["Folder_Name"]  
    values = [os.path.basename(main_folder)]  # Add the folder name as the first value

    # Iterate over each column except the first one (Folder_Name)
    for col in data.columns[1:]:
        # Calculate max and min
        col_max = data[col].max()
        col_min = data[col].min()
        
        # Calculate Boltzmann-weighted average
        col_values = data[col].values
        folder_names = data["Folder_Name"].values
        boltzmann_average = sum(
            boltzmann_weights.get(folder_name, 0) * value
            for folder_name, value in zip(folder_names, col_values)
        )

        # Get the value for the row corresponding to "conformer_1"
        conformer_1_row = data.loc[data["Folder_Name"].str.endswith("conformer_1"), col]
        if not conformer_1_row.empty:
            scomformer_value = conformer_1_row.values[0]
        else:
            scomformer_value = None
            print(f"Warning: No conformer_1 found for column {col}")

        # Append descriptor names and corresponding values
        descriptors.extend([f"{col}_max", f"{col}_min", f"{col}_bol", f"{col}_scomformer"])
        values.extend([col_max, col_min, boltzmann_average, scomformer_value])

    # Load RDKIT_descriptors_results.csv and extract columns from the third one onward
    rdkit_path = os.path.join(main_folder, "RDKIT_descriptors_results.csv")
    if os.path.exists(rdkit_path):
        rdkit_data = pd.read_csv(rdkit_path)
        if rdkit_data.shape[1] > 2:  # Ensure there are more than 2 columns
            rdkit_descriptors = rdkit_data.columns[2:].tolist()  # Get third column onward
            rdkit_values = rdkit_data.iloc[0, 2:].tolist()  # Get their corresponding values
            descriptors.extend(rdkit_descriptors)  # Append to descriptors
            values.extend(rdkit_values)  # Append to values
        else:
            print("RDKIT_descriptors_results.csv does not have enough columns.")
    else:
        print("RDKIT_descriptors_results.csv not found.")

    # Create a DataFrame for the descriptors
    descriptor_df = pd.DataFrame([descriptors, values])
    
    # Save the descriptors to the output CSV
    output_path = os.path.join(main_folder, output_csv)
    descriptor_df.to_csv(output_path, index=False, header=False)
    print(f"Descriptors saved to {output_path}")


# Main execution
if __name__ == "__main__":
    main_folder = os.getcwd()  # Get the current working directory
    input_csv = "merge_five.csv"  # Input merged CSV file
    output_csv = "descriptors.csv"  # Output descriptors file

    process_merge_all_csv(main_folder, input_csv, output_csv)

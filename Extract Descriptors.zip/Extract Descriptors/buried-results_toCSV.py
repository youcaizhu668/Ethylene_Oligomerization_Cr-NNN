import pandas as pd
import os

def txt_to_csv(input_txt_path, output_csv_path):
    # Step 1: Get the folder name
    folder_name = os.path.basename(os.path.dirname(os.path.abspath(input_txt_path)))

    # Step 2: Read the TXT file
    with open(input_txt_path, "r") as file:
        lines = file.readlines()

    # Step 3: Extract headers and data
    headers = ["Folder_Name"]  # Initialize headers with folder name
    values = [folder_name]  # Initialize values with folder name

    # The first line is the header line, process it separately
    column_titles = lines[0].strip().split()
    
    # Process each subsequent row
    for line in lines[1:]:
        # Split the row into columns
        columns = line.strip().split()
        radius = columns[0]  # The first column is the radius
        data_values = columns[1:]  # Remaining columns are the data

        # Generate column headers and append values
        for idx, value in enumerate(data_values):
            headers.append(f"{radius}_{column_titles[idx + 1]}")
            values.append(value)

    # Step 4: Create a DataFrame for the headers and values
    final_df = pd.DataFrame([headers, values])

    # Step 5: Save to a CSV file
    final_df.to_csv(output_csv_path, index=False, header=False)
    print(f"Converted file saved to: {output_csv_path}")


# Input TXT file path and output CSV file path
input_txt_path = "Buried_results.txt"  # Replace with your input file path
output_csv_path = "Buried-results.csv"  # Replace with your desired output file path

# Call the function
txt_to_csv(input_txt_path, output_csv_path)

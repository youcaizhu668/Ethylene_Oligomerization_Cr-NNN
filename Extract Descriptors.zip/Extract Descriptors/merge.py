import os
import pandas as pd

# Step 1: Run scripts in subfolders starting with "L"
def run_script_in_subfolders(main_folder):
    # Iterate through all subfolders in the main folder
    for subfolder in os.listdir(main_folder):
        # Check if the subfolder starts with "L"
        if subfolder.startswith("L"):
            subfolder_path = os.path.join(main_folder, subfolder)

            # Check if it's a directory
            if os.path.isdir(subfolder_path):
                print(f"Running script in: {subfolder_path}")
                os.chdir(subfolder_path)
                # Run the Python scripts in the subfolder
                #os.system(f"python /home/home/zhuyoucai/0_script/NNN_ML_lib/python/sterimol_AND_cone-results_toCSV.py")  
                os.system(f"python /home/home/zhuyoucai/0_script/NNN_ML_lib/python/ACSF_results_toCSV.py")  
                os.system(f"python /home/home/zhuyoucai/0_script/NNN_ML_lib/python/buried-results_toCSV.py")  
                os.system(f"python /home/home/zhuyoucai/0_script/NNN_ML_lib/python/electronic-results_toCSV.py")  
                os.system(f"python /home/home/zhuyoucai/0_script/NNN_ML_lib/python/geometric_results_toCSV.py")  
                print(f"Finished running script in: {subfolder_path}")

# Step 2: Merge each file type into a single CSV
def merge_csv_by_type(main_folder, csv_filename, output_csv_name):
    all_data = []  # List to store data from all subfolders

    # Iterate through all subfolders in the main folder
    for subfolder in os.listdir(main_folder):
        # Only process folders starting with "L"
        if subfolder.startswith("L"):
            subfolder_path = os.path.join(main_folder, subfolder)

            if os.path.isdir(subfolder_path):  # Check if it's a directory
                # Construct the path to the specific CSV file
                csv_file_path = os.path.join(subfolder_path, csv_filename)
                if os.path.exists(csv_file_path):  # Check if the file exists
                    df = pd.read_csv(csv_file_path)
                    all_data.append(df)  # Append the DataFrame to the list
                else:
                    print(f"CSV file {csv_filename} not found in {subfolder}")

    # Combine all data into a single DataFrame
    if all_data:
        combined_df = pd.concat(all_data, ignore_index=True)

        # Sorting logic
        if "Folder_Name" in combined_df.columns:
            # Extract numbers from Folder_Name and sort by the extracted numbers
            combined_df["Sort_Key"] = combined_df["Folder_Name"].str.extract(r'(\d+)$').astype(int)
            combined_df = combined_df.sort_values(by="Sort_Key").drop(columns=["Sort_Key"])

        # Save to the main folder instead of the subfolder
        output_path = os.path.join(main_folder, output_csv_name)
        combined_df.to_csv(output_path, index=False)
        print(f"Combined CSV saved to {output_path}")
    else:
        print(f"No data found for {csv_filename}")

# Step 3: Merge all "merge_*.csv" into a single CSV
def merge_all_csv(main_folder, output_csv_name):
    # Define the files to merge
    csv_files = [
        "merge_ACSF_results.csv",
        "merge_Buried_results.csv",
        "merge_electronic_results.csv",
        "merge_Geometric_results.csv",
        #"merge_Sterimol_AND_cone_results.csv"
    ]

    # Initialize a list to store DataFrames
    dataframes = []

    # Read each CSV file and add to the list
    for file_name in csv_files:
        file_path = os.path.join(main_folder, file_name)
        if os.path.exists(file_path):
            df = pd.read_csv(file_path)
            dataframes.append(df)
        else:
            print(f"File {file_name} not found in {main_folder}")

    # Merge all DataFrames on the "Folder_Name" column
    if dataframes:
        merged_df = dataframes[0]
        for df in dataframes[1:]:
            merged_df = pd.merge(merged_df, df, on="Folder_Name", how="outer")  # Merge on Folder_Name
        
        # Save the final merged DataFrame to a CSV file
        output_path = os.path.join(main_folder, output_csv_name)
        merged_df.to_csv(output_path, index=False)
        print(f"All files merged and saved to {output_path}")
    else:
        print("No valid CSV files to merge.")

# Main execution
if __name__ == "__main__":
    # Set the main folder to the current working directory
    main_folder = os.getcwd()  # Get the current working directory

    # Step 1: Run scripts in subfolders starting with "L"
    run_script_in_subfolders(main_folder)

    # Step 2: Merge each file type into a single CSV
    csv_files_to_merge = {
        "ACSF_results.csv": "merge_ACSF_results.csv",
        "Buried-results.csv": "merge_Buried_results.csv",
        "Electronic-results.csv": "merge_electronic_results.csv",
        "Geometric_results.csv": "merge_Geometric_results.csv"
        #"Sterimol_AND_cone-results.csv": "merge_Sterimol_AND_cone_results.csv"
    }

    for csv_filename, output_csv_name in csv_files_to_merge.items():
        merge_csv_by_type(main_folder, csv_filename, output_csv_name)

    # Step 3: Merge all "merge_*.csv" into a single CSV
    merge_all_csv(main_folder, "merge_five.csv")

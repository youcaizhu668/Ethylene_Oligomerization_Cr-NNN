# -*- coding: utf-8 -*-

import numpy as np

# Cutoff function
def cutoff_function(R, Rc):
    if R > Rc:
        return 0
    return 0.5 * (np.cos(np.pi * R / Rc) + 1)

# G1 calculation
def get_G1(positions, Rc, atom_index=None):
    natoms = len(positions)
    G1_values = []
    indices_to_calculate = [atom_index] if atom_index is not None else range(natoms)

    for i in indices_to_calculate:
        G1_i = 0
        for j in range(natoms):
            if i == j:
                continue
            Rij = np.linalg.norm(positions[i] - positions[j])
            G1_i += cutoff_function(Rij, Rc)
        G1_values.append([G1_i])  # Store as a list to keep the same format as G2, G3, etc.

    return np.array(G1_values)

# G2 calculation
def get_G2(positions, Rc, g2_params, atom_index=None):
    natoms = len(positions)
    G2_values = []
    indices_to_calculate = [atom_index] if atom_index is not None else range(natoms)

    for i in indices_to_calculate:
        G2_i = []
        for eta, Rs in g2_params:
            G2_val = 0
            for j in range(natoms):
                if i == j:
                    continue
                Rij = np.linalg.norm(positions[i] - positions[j])
                G2_val += np.exp(-eta * (Rij - Rs)**2) * cutoff_function(Rij, Rc)
            G2_i.append(G2_val)
        G2_values.append(G2_i)
    return np.array(G2_values)

# Compute G3 symmetry function
def get_G3(positions, Rc, g3_params, atom_index=None):
    natoms = len(positions)
    G3_values = []
    
    for i in range(natoms):
        if atom_index is not None and i != atom_index:
            continue
        G3_i = []
        for kappa in g3_params:
            G3_val = 0
            for j in range(natoms):
                if i == j:
                    continue
                Rij = np.linalg.norm(positions[i] - positions[j])
                G3_val += np.cos(kappa * Rij) * cutoff_function(Rij, Rc)
            G3_i.append(G3_val)
        G3_values.append(G3_i)
    
    return np.array(G3_values)

# Compute G4 symmetry function
def compute_G4(positions, Rc, g4_params, atom_index=None):
    natoms = len(positions)
    G4_values = []
    
    for i in range(natoms):
        if atom_index is not None and i != atom_index:
            continue
        G4_i = []
        for eta, zeta, lambd in g4_params:
            G4_val = 0
            for j in range(natoms):
                if j == i:
                    continue
                for k in range(natoms):
                    if k == i or k == j:
                        continue
                    R_ij = np.linalg.norm(positions[j] - positions[i])
                    R_ik = np.linalg.norm(positions[k] - positions[i])
                    R_jk = np.linalg.norm(positions[j] - positions[k])
                    theta_degrees, cos_theta_ijk = calculate_angle(positions[i], positions[j], positions[k])
                    angular_part = (1 + lambd * cos_theta_ijk) ** zeta
                    exponential_part = np.exp(-eta * (R_ij**2 + R_ik**2 + R_jk**2))
                    fc_ij = cutoff_function(R_ij, Rc)
                    fc_ik = cutoff_function(R_ik, Rc)
                    fc_jk = cutoff_function(R_jk, Rc)
                    G4_val += angular_part * exponential_part * fc_ij * fc_ik * fc_jk
            G4_val *= 2 ** (1 - zeta)
            G4_i.append(G4_val)
        G4_values.append(G4_i)
    
    return np.array(G4_values)

# Compute G5 symmetry function
def compute_G5(positions, Rc, g5_params, atom_index=None):
    natoms = len(positions)
    G5_values = []

    for i in range(natoms):
        if atom_index is not None and i != atom_index:
            continue
        G5_i = []
        for eta, zeta, lambd in g5_params:
            G5_val = 0
            for j in range(natoms):
                if j == i:
                    continue
                for k in range(natoms):
                    if k == i or k == j:
                        continue
                    R_ij = np.linalg.norm(positions[j] - positions[i])
                    R_ik = np.linalg.norm(positions[k] - positions[i])
                    theta_degrees, cos_theta_ijk = calculate_angle(positions[i], positions[j], positions[k])
                    angular_part = (1 + lambd * cos_theta_ijk) ** zeta
                    exponential_part = np.exp(-eta * (R_ij**2 + R_ik**2))
                    fc_ij = cutoff_function(R_ij, Rc)
                    fc_ik = cutoff_function(R_ik, Rc)
                    G5_val += angular_part * exponential_part * fc_ij * fc_ik
            G5_i.append(G5_val)
        G5_values.append(G5_i)
    
    return np.array(G5_values)

# Calculate the angle ��ijk
def calculate_angle(r_i, r_j, r_k):
    R_ij = r_j - r_i
    R_ik = r_k - r_i
    cos_theta = np.dot(R_ij, R_ik) / (np.linalg.norm(R_ij) * np.linalg.norm(R_ik))
    return np.degrees(np.arccos(cos_theta)), cos_theta

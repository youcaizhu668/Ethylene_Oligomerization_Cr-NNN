# -*- coding: utf-8 -*-
import os
from morfeus import BuriedVolume, read_xyz
import re

current_folder = os.path.basename(os.getcwd())
# Scan all .xyz files in the current directory
xyz_files = [f for f in os.listdir('.') if f.endswith('.xyz') and f.startswith(current_folder)]

# Define the list of radii to calculate
radii = [3, 3.5, 4, 5, 6]

# Initialize a dictionary to store the results for each radius
results = {radius: [] for radius in radii}

# Process each .xyz file
for xyz_file in xyz_files:
    try:
        # Read elements and coordinates from the .xyz file
        elements, coordinates = read_xyz(xyz_file)
        
        # Process for each radius
        for radius in radii:
            bv = BuriedVolume(elements, coordinates, 1, radius=radius)
            
            # Extract buried volume percentage
            vbur_percent = bv.fraction_buried_volume * 100  # Convert to percentage
            
            # Calculate buried volume with specific atoms for analysis
            bv = BuriedVolume(elements, coordinates, 1, radius=radius, z_axis_atoms=[3], xz_plane_atoms=[2])
            
            # Perform octant and quartant analysis
            bv.octant_analysis()  # Populate the bv.octants dictionary
            
            # Extract octant data
            percent_buried_volume = bv.octants['percent_buried_volume']
            buried_volume = bv.octants['buried_volume']
            free_volume = bv.octants['free_volume']

            # Extract quartant data
            q_percent_buried_volume = bv.quadrants['percent_buried_volume']
            q_buried_volume = bv.quadrants['buried_volume']
            q_free_volume = bv.quadrants['free_volume']

            # Calculate min, max, and average for each octant and quartant data
            percent_buried_values = list(percent_buried_volume.values())
            buried_values = list(buried_volume.values())
            free_values = list(free_volume.values())

            q_percent_buried_values = list(q_percent_buried_volume.values())
            q_buried_values = list(q_buried_volume.values())
            q_free_values = list(q_free_volume.values())

            percent_buried_min = min(percent_buried_values)
            percent_buried_max = max(percent_buried_values)
            percent_buried_ave = sum(percent_buried_values) / len(percent_buried_values)

            buried_min = min(buried_values)
            buried_max = max(buried_values)
            buried_ave = sum(buried_values) / len(buried_values)

            free_min = min(free_values)
            free_max = max(free_values)
            free_ave = sum(free_values) / len(free_values)

            q_percent_buried_min = min(q_percent_buried_values)
            q_percent_buried_max = max(q_percent_buried_values)
            q_percent_buried_ave = sum(q_percent_buried_values) / len(q_percent_buried_values)

            q_buried_min = min(q_buried_values)
            q_buried_max = max(q_buried_values)
            q_buried_ave = sum(q_buried_values) / len(q_buried_values)

            q_free_min = min(q_free_values)
            q_free_max = max(q_free_values)
            q_free_ave = sum(q_free_values) / len(q_free_values)

            # Extract numeric part from the file name for sorting (e.g., L100075 -> 100075)
            numeric_part = int(re.search(r'\d+', xyz_file).group())

            # Append result as a dictionary for easier processing
            results[radius].append({
                "numeric_part": numeric_part,
                "molname": xyz_file,
                "%Vbur": vbur_percent,
                "O_percent_buried_volume": percent_buried_volume,
                "O_buried_volume": buried_volume,
                "O_free_volume": free_volume,
                "Q_percent_buried_volume": q_percent_buried_volume,
                "Q_buried_volume": q_buried_volume,
                "Q_free_volume": q_free_volume,
                "O_percent_buried_volume_min": percent_buried_min,
                "O_percent_buried_volume_max": percent_buried_max,
                "O_percent_buried_volume_ave": percent_buried_ave,
                "O_buried_volume_min": buried_min,
                "O_buried_volume_max": buried_max,
                "O_buried_volume_ave": buried_ave,
                "O_free_volume_min": free_min,
                "O_free_volume_max": free_max,
                "O_free_volume_ave": free_ave,
                "Q_percent_buried_volume_min": q_percent_buried_min,
                "Q_percent_buried_volume_max": q_percent_buried_max,
                "Q_percent_buried_volume_ave": q_percent_buried_ave,
                "Q_buried_volume_min": q_buried_min,
                "Q_buried_volume_max": q_buried_max,
                "Q_buried_volume_ave": q_buried_ave,
                "Q_free_volume_min": q_free_min,
                "Q_free_volume_max": q_free_max,
                "Q_free_volume_ave": q_free_ave,
            })

    except Exception as e:
        # Append error information if processing fails
        for radius in radii:
            results[radius].append({
                "numeric_part": float('inf'),
                "molname": xyz_file,
                "%Vbur": f"Error: {e}",
                "O_percent_buried_volume": {i: "Error" for i in range(8)},
                "O_buried_volume": {i: "Error" for i in range(8)},
                "O_free_volume": {i: "Error" for i in range(8)},
                "Q_percent_buried_volume": {i: "Error" for i in range(1,5)},
                "Q_buried_volume": {i: "Error" for i in range(1,5)},
                "Q_free_volume": {i: "Error" for i in range(1,5)},
                "O_percent_buried_volume_min": "Error",
                "O_percent_buried_volume_max": "Error",
                "O_percent_buried_volume_ave": "Error",
                "O_buried_volume_min": "Error",
                "O_buried_volume_max": "Error",
                "O_buried_volume_ave": "Error",
                "O_free_volume_min": "Error",
                "O_free_volume_max": "Error",
                "O_free_volume_ave": "Error",
                "Q_percent_buried_volume_min": "Error",
                "Q_percent_buried_volume_max": "Error",
                "Q_percent_buried_volume_ave": "Error",
                "Q_buried_volume_min": "Error",
                "Q_buried_volume_max": "Error",
                "Q_buried_volume_ave": "Error",
                "Q_free_volume_min": "Error",
                "Q_free_volume_max": "Error",
                "Q_free_volume_ave": "Error",
            })

# Sort results by the numeric part of the file name
for radius in radii:
    results[radius].sort(key=lambda x: x["numeric_part"])

# Output file name
output_file = "Buried_results.txt"

# Define column headers
headers = [
    "Radius", "%Vbur",
    # Octant data
    *[f"O_percent_buried_volume_{i}" for i in range(8)],
    *[f"O_buried_volume_{i}" for i in range(8)],
    *[f"O_free_volume_{i}" for i in range(8)],
    # Quartant data
    *[f"Q_percent_buried_volume_{i}" for i in range(1,5)],
    *[f"Q_buried_volume_{i}" for i in range(1,5)],
    *[f"Q_free_volume_{i}" for i in range(1,5)],
    # Summary statistics
    "O_percent_buried_volume_min", "O_percent_buried_volume_max", "O_percent_buried_volume_ave",
    "O_buried_volume_min", "O_buried_volume_max", "O_buried_volume_ave",
    "O_free_volume_min", "O_free_volume_max", "O_free_volume_ave",
    "Q_percent_buried_volume_min", "Q_percent_buried_volume_max", "Q_percent_buried_volume_ave",
    "Q_buried_volume_min", "Q_buried_volume_max", "Q_buried_volume_ave",
    "Q_free_volume_min", "Q_free_volume_max", "Q_free_volume_ave",
]

# Define column widths
# Adjusted to accommodate data with up to 18 characters, including decimal points
column_widths = [
    8,    # Radius
    20,   # %Vbur
    # Octant data
    *[30 for _ in range(8)],  # O_percent_buried_volume_0-7
    *[30 for _ in range(8)],  # O_buried_volume_0-7
    *[30 for _ in range(8)],  # O_free_volume_0-7
    # Quartant data
    *[30 for _ in range(4)],  # Q_percent_buried_volume_1-4
    *[30 for _ in range(4)],  # Q_buried_volume_1-4
    *[30 for _ in range(4)],  # Q_free_volume_1-4
    # Summary statistics
    *[30 for _ in range(3)],  # O_percent_buried_volume_min, max, ave
    *[30 for _ in range(3)],  # O_buried_volume_min, max, ave
    *[30 for _ in range(3)],  # O_free_volume_min, max, ave
    *[30 for _ in range(3)],  # Q_percent_buried_volume_min, max, ave
    *[30 for _ in range(3)],  # Q_buried_volume_min, max, ave
    *[30 for _ in range(3)],  # Q_free_volume_min, max, ave
]

# Ensure headers and column_widths have the same length
assert len(headers) == len(column_widths), "Headers and column_widths lengths do not match!"

# Write results to the output file
with open(output_file, "w", encoding='utf-8') as f:
    # Write header row with centered alignment
    header_line = "".join([h.center(w) for h, w in zip(headers, column_widths)]) + "\n"
    f.write(header_line)

    # Write each data row
    for radius in radii:
        for result in results[radius]:
            row = []
            row.append(f"{radius}".center(column_widths[0]))  # Radius
            # Format %Vbur to 4 decimal places
            vbur = f"{result['%Vbur']:.4f}" if isinstance(result['%Vbur'], (int, float)) else result['%Vbur']
            row.append(f"{vbur}".center(column_widths[1]))  # %Vbur

            # Octant data
            for i in range(8):
                value = result["O_percent_buried_volume"].get(i, "N/A")
                formatted = f"{value:.4f}" if isinstance(value, (int, float)) else value
                row.append(f"{formatted}".center(column_widths[2 + i]))
            for i in range(8):
                value = result["O_buried_volume"].get(i, "N/A")
                formatted = f"{value:.4f}" if isinstance(value, (int, float)) else value
                row.append(f"{formatted}".center(column_widths[10 + i]))
            for i in range(8):
                value = result["O_free_volume"].get(i, "N/A")
                formatted = f"{value:.4f}" if isinstance(value, (int, float)) else value
                row.append(f"{formatted}".center(column_widths[18 + i]))

            # Quartant data
            for i in range(1, 5):
                value = result["Q_percent_buried_volume"].get(i, "N/A")
                formatted = f"{value:.4f}" if isinstance(value, (int, float)) else value
                row.append(f"{formatted}".center(column_widths[26 + (i - 1)]))
            for i in range(1, 5):
                value = result["Q_buried_volume"].get(i, "N/A")
                formatted = f"{value:.4f}" if isinstance(value, (int, float)) else value
                row.append(f"{formatted}".center(column_widths[30 + (i - 1)]))
            for i in range(1, 5):
                value = result["Q_free_volume"].get(i, "N/A")
                formatted = f"{value:.4f}" if isinstance(value, (int, float)) else value
                row.append(f"{formatted}".center(column_widths[34 + (i - 1)]))

            # Summary statistics
            # O_percent_buried_volume_min, max, ave
            for key in ["O_percent_buried_volume_min", "O_percent_buried_volume_max", "O_percent_buried_volume_ave"]:
                value = result[key]
                formatted = f"{value:.4f}" if isinstance(value, (int, float)) else value
                row.append(f"{formatted}".center(column_widths[38 + headers.index(key) - headers.index("O_percent_buried_volume_min")]))
            
            # O_buried_volume_min, max, ave
            for key in ["O_buried_volume_min", "O_buried_volume_max", "O_buried_volume_ave"]:
                value = result[key]
                formatted = f"{value:.4f}" if isinstance(value, (int, float)) else value
                row.append(f"{formatted}".center(column_widths[41 + headers.index(key) - headers.index("O_buried_volume_min")]))
            
            # O_free_volume_min, max, ave
            for key in ["O_free_volume_min", "O_free_volume_max", "O_free_volume_ave"]:
                value = result[key]
                formatted = f"{value:.4f}" if isinstance(value, (int, float)) else value
                row.append(f"{formatted}".center(column_widths[44 + headers.index(key) - headers.index("O_free_volume_min")]))
            
            # Q_percent_buried_volume_min, max, ave
            for key in ["Q_percent_buried_volume_min", "Q_percent_buried_volume_max", "Q_percent_buried_volume_ave"]:
                value = result[key]
                formatted = f"{value:.4f}" if isinstance(value, (int, float)) else value
                row.append(f"{formatted}".center(column_widths[47 + headers.index(key) - headers.index("Q_percent_buried_volume_min")]))
            
            # Q_buried_volume_min, max, ave
            for key in ["Q_buried_volume_min", "Q_buried_volume_max", "Q_buried_volume_ave"]:
                value = result[key]
                formatted = f"{value:.4f}" if isinstance(value, (int, float)) else value
                row.append(f"{formatted}".center(column_widths[50 + headers.index(key) - headers.index("Q_buried_volume_min")]))
            
            # Q_free_volume_min, max, ave
            for key in ["Q_free_volume_min", "Q_free_volume_max", "Q_free_volume_ave"]:
                value = result[key]
                formatted = f"{value:.4f}" if isinstance(value, (int, float)) else value
                row.append(f"{formatted}".center(column_widths[53 + headers.index(key) - headers.index("Q_free_volume_min")]))
            
            # Combine all columns into a single row string and write to the file
            row_line = "".join(row) + "\n"
            f.write(row_line)


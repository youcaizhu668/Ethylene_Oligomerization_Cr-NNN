import os
import pandas as pd

# Get the current working directory as the main folder path
main_folder = os.getcwd()

# Create an empty DataFrame to store the merged data
final_df = pd.DataFrame()

# Iterate over all subfolders in the main folder
for folder_name in os.listdir(main_folder):
    folder_path = os.path.join(main_folder, folder_name)
    
    # Ensure the path is a directory
    if os.path.isdir(folder_path):
        # Construct the path to the descriptors.csv file in each subfolder
        csv_file_path = os.path.join(folder_path, 'descriptors.csv')
        
        # Ensure the CSV file exists
        if os.path.exists(csv_file_path):
            # Read the CSV file
            df = pd.read_csv(csv_file_path)
            
            # Append the data to the final DataFrame
            final_df = pd.concat([final_df, df], ignore_index=True)

# Sort the DataFrame by the first column (typically the 'name' or similar column)
if not final_df.empty:  # Ensure the final DataFrame is not empty
    final_df = final_df.sort_values(by=final_df.columns[0])  # Sort by the first column

# Save the merged DataFrame as a final CSV file
final_csv_path = os.path.join(main_folder, 'final_descriptors.csv')
final_df.to_csv(final_csv_path, index=False)

print(f"Final CSV file saved at: {final_csv_path}")

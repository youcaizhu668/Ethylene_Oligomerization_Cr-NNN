import csv
import sys
import os
import re
from rdkit import Chem

# Function to generate SMILES based on the PNP backbone and R groups
def generate_smiles(R1, R2, R3):
    # PNP backbone template with placeholders for R groups
    backbone = "[Cr]1([N+](=C2N(C3=[N+]1C({R1})=CC({R2})=C3)({R3}))C({R1})=CC({R2})=C2)(Cl)(Cl)Cl"
    
    # Replace 'H' with empty strings and clean up placeholders with outer structure
    R_groups = {'R1': R1, 'R2': R2, 'R3': R3}
    for R, value in R_groups.items():
        if value == 'H':
            # Remove the entire block containing the placeholder and parentheses
            backbone = re.sub(rf'\(\{{{R}\}}\)', '', backbone)  # Remove ({R})
            backbone = backbone.replace(f"{{{R}}}", "")  # Remove leftover placeholders
        else:
            # Replace placeholders with actual R group values
            backbone = backbone.replace(f"{{{R}}}", value)
    
    # Use regex to remove any (H) explicitly
    cleaned_smiles = re.sub(r'\(H\)', '', backbone)
    
    # Remove any leftover empty parentheses caused by placeholder removal
    cleaned_smiles = cleaned_smiles.replace("()", "").strip()
    
    return cleaned_smiles

# Function to normalize and filter SMILES using RDKit
def normalize_smiles(smiles):
    try:
        # Convert the SMILES to a molecule object using RDKit
        mol = Chem.MolFromSmiles(smiles)
        if mol:
            # Convert the molecule back to a canonical SMILES
            return Chem.MolToSmiles(mol, canonical=True)
    except:
        return None  # Return None if the SMILES is invalid or cannot be parsed
    return None

# Function to process the CSV file, generate, normalize, and write SMILES
def process_csv(input_csv, output_csv):
    rows = []

    # Read the input CSV file
    with open(input_csv, 'r', encoding='utf-8', errors='ignore') as csvfile:
        reader = csv.reader(csvfile)
        header = next(reader)  # Read the header row

        for row in reader:
            molecule_name = row[0]
            R1 = row[1]
            R2 = row[2]
            R3 = row[3]

            # Generate SMILES using the R groups
            generated_smiles = generate_smiles(R1, R2, R3)
            
            if generated_smiles:
                # Normalize the generated SMILES
                canonical_smiles = normalize_smiles(generated_smiles)
                
                # If the SMILES is valid, add it to the row
                if canonical_smiles:
                    # Append the original and canonical SMILES to the row
                    row.append(generated_smiles)  # Add original SMILES
                    row.append(canonical_smiles)  # Add canonical SMILES
                    rows.append(row)

    # Write the rows to a new CSV file
    with open(output_csv, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        # Write the header, including new columns for the original and canonical SMILES
        header.append('Original SMILES')
        header.append('Generated SMILES (Canonical)')
        writer.writerow(header)

        # Write all the rows
        writer.writerows(rows)

# Entry point of the script
if __name__ == "__main__":
    if len(sys.argv) == 2:
        input_csv = sys.argv[1]  # Input CSV file from the command line
        
        # Generate output CSV file name by adding "_output" before the file extension
        output_csv = f"smi.csv"

        # Process the CSV file, generate SMILES, normalize, and write to the output file
        process_csv(input_csv, output_csv)

        print(f"Generated SMILES have been saved to {output_csv}")
    else:
        print("Usage: python script.py <input_csv_file>")

#!/bin/bash
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=40
#SBATCH -o runlog
#SBATCH --time=96:00:00
#SBATCH -p q1

ncore=20
nmem=30

ulimit -s unlimited
ulimit -l unlimited

WORKDIR=${SLURM_SUBMIT_DIR}
HN=$(echo ${SLURMD_NODENAME})
mkdir -p /state/partition1/tmp/${USER}/${SLURM_JOB_ID}

##Environment setting for Gaussian
export GAUSS_EXEDIR="/home/mcpe/apps/g09e01"
export PATH="/home/mcpe/apps/g09e01":$PATH
export GAUSS_SCRDIR="/state/partition1/tmp/${USER}/${SLURM_JOB_ID}"

##END of Environment setting for Gaussian

cd ${WORKDIR}
rm *.fchk *_DONE *_FAILED *running*   2>   /dev/null

cp ${WORKDIR}/* ${GAUSS_SCRDIR}
cd ${GAUSS_SCRDIR}

GJFINPUT=$(ls *.gjf)

##--run jobs--
for FILENAME in ${GJFINPUT}; do
FILENAME=${FILENAME%.gjf}
dos2unix  ${FILENAME}.gjf


sed -i "/^%[nN][pP]/ c\%nprocshared=${ncore}" ${FILENAME}.gjf
sed -i "/^%[mM][eE]/ c\%mem=${nmem}GB" ${FILENAME}.gjf
cp  ${FILENAME}.gjf ${WORKDIR}/
echo "------[${FILENAME}]------"

touch ${WORKDIR}/"${SLURM_JOB_ID}"
touch ${WORKDIR}/"${HN}_running"

echo "Job [${FILENAME}] start at" `date`
printf "\n"
echo " Job [${FILENAME}] running host is:"  ${HOSTNAME}
echo " Job [${FILENAME}] running path is:  $GAUSS_SCRDIR"
printf "\n"


g09 <${FILENAME}.gjf> ${WORKDIR}/${FILENAME}.log

done
cp ${WORKDIR}/${FILENAME}.log ${GAUSS_SCRDIR}

rm ${WORKDIR}/"${SLURM_JOB_ID}"
rm ${WORKDIR}/"${HN}_running"
echo "------[${FILENAME}]------"
##--END of jobs--

##--Reformat checkpoint--
if [ "$( tail -n 1 ${FILENAME}.log | grep "Normal termination of Gaussian" )" ]; then
  echo "Job [${FILENAME}] finish at" `date`
  echo " Job [${FILENAME}] completed, congratulations!"
  touch   ${WORKDIR}/${SLURM_JOB_ID}_DONE

#  for j in ${GAUSS_SCRDIR}/*.chk; do
#  k=${j%.chk}
#  rm $k ${k}.fchk 2>   /dev/null
#  formchk -3 $j
#  rm $j
#  unfchk $k $j
#  rm $k ${k}.fchk 2>   /dev/null
#  cp $j ${WORKDIR}
#  done

  cp ${FILENAME}.chk  ${WORKDIR}

else
  echo " Job [${FILENAME}] failed" `date`
  touch   ${WORKDIR}/${SLURM_JOB_ID}_FAILED
  cp ${FILENAME}.chk  ${WORKDIR}
fi

rm -rf /state/partition1/tmp/${USER}/${SLURM_JOB_ID}

printf "\n"
echo "Job finally stoped at" `date`
printf "\n\n\n"

#---END of the Script---

